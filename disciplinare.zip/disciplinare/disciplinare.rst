
.. _h2c946551c717045362a939453b2632:

Premessa
========

La progressiva diffusione delle nuove tecnologie informatiche, ed in particolare il libero accesso alla rete tramite i personal computer, espone le organizzazioni a rischi di un coinvolgimento sia patrimoniale sia penale, creando problemi alla sicurezza e all’immagine.

L’utilizzo delle risorse informatiche e telematiche aziendali deve sempre ispirarsi al principio di diligenza e correttezza, atteggiamenti questi destinati a sorreggere ogni atto o comportamento posto in essere nell’ambito del rapporto di lavoro.

Il personal computer, i relativi programmi e/o applicazioni e/o dati ed archivi affidati in uso ai dipendenti sono strumenti di lavoro di proprietà dell’Azienda. Tutto quanto messo a disposizione, ricevuto, rilasciato e comunque memorizzato sul posto di lavoro e sui mezzi di comunicazione è e rimane di proprietà dell’Azienda.


.. bottom of content
